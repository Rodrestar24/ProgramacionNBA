package modelo.Producto;

public class Trofeo {
    private String nombreEquipo;
    private int año;

    public Trofeo(String nombreEquipo, int año) {
        this.nombreEquipo = nombreEquipo;
        this.año = año;
    }

    public String getNombreEquipo() {
        return nombreEquipo;
    }

    public int getAño() {
        return año;
    }
}
