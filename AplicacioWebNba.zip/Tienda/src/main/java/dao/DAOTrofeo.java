package dao;

import java.util.ArrayList;
import java.util.List;

import modelo.Producto.Trofeo;

public class DAOTrofeo {
    private static List<Trofeo> trofeos = new ArrayList<>();

    static {
    	trofeos.add(new Trofeo("Los Angeles Lakers", 2020));
        trofeos.add(new Trofeo("Los Angeles Clippers", 2025));
        trofeos.add(new Trofeo("Brooklyn Nets", 2023));
        trofeos.add(new Trofeo("Miami Heat", 2006));
        trofeos.add(new Trofeo("Boston Celtics", 2008));
        trofeos.add(new Trofeo("Chicago Bulls", 1991));
        trofeos.add(new Trofeo("Houston Rockets", 1994));
        trofeos.add(new Trofeo("San Antonio Spurs", 1999));
        trofeos.add(new Trofeo("Golden State Warriors", 2015));
        trofeos.add(new Trofeo("Toronto Raptors", 2019));
        trofeos.add(new Trofeo("Cleveland Cavaliers", 2016));
        trofeos.add(new Trofeo("Dallas Mavericks", 2011));
        trofeos.add(new Trofeo("Detroit Pistons", 1989));
        trofeos.add(new Trofeo("Indiana Pacers", 2000));
        trofeos.add(new Trofeo("Milwaukee Bucks", 1971));
        trofeos.add(new Trofeo("New York Knicks", 1970));
        trofeos.add(new Trofeo("Oklahoma City Thunder", 1979));
        trofeos.add(new Trofeo("Philadelphia 76ers", 1983));
        trofeos.add(new Trofeo("Utah Jazz", 2021));
        trofeos.add(new Trofeo("Portland Trail Blazers", 1977));
    }

    public List<Trofeo> getTrofeos() {
        return trofeos;
    }
}
