package gestion;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import dao.DAOTrofeo;
import modelo.Producto.Trofeo;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;

@WebServlet("/gestion.ListarEquiposNBA")
public class ServletListarEquiposNBA extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String orden = request.getParameter("orden");
        
        DAOTrofeo daoTrofeo = new DAOTrofeo();
        List<Trofeo> listaTrofeos = daoTrofeo.getTrofeos();
        
        if (orden != null && orden.equals("alfabetico")) {
            listaTrofeos.sort(Comparator.comparing(Trofeo::getNombreEquipo));
        }
        
        HttpSession session = request.getSession();
        session.setAttribute("trofeos", listaTrofeos);
        response.sendRedirect("equipos.jsp");
    }
}
